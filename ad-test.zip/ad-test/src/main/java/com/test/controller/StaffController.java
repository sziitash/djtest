package com.test.controller;

import com.test.service.staff.Staff;
import com.test.service.staff.StaffServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/Staff")
public class StaffController {

    @Autowired
    StaffServiceI staffServiceI;

    @RequestMapping("getStaffList")
    @ResponseBody
    public Object getStaffList() {

        return staffServiceI.getStaffList();

    }

    @RequestMapping("getObjectById")
    @ResponseBody
    public Object getObjectById(@RequestParam(value = "id") int id) {

        Map
                <Object, Object> params = new HashMap
                <Object, Object>();
        params.put("id", id);

        return staffServiceI
                .getStaffByParam(params);

    }

    @RequestMapping("addStaff")
    @ResponseBody
    public Object add(@RequestParam(value = "name") String name, @RequestParam(value = "img_url") String img_url, @RequestParam(value = "projectId") String projectId) throws ParseException {

        Staff staff = Staff.buildWithOutId(name, img_url, projectId);
        return staffServiceI.add(staff);

    }

    @RequestMapping("editStaff")
    @ResponseBody
    public Object edit(@RequestParam(value = "name") String name, @RequestParam(value = "id") int id, @RequestParam(value = "img_url") String img_url, @RequestParam(value = "projectId") String projectId) throws ParseException {

        Staff staff = Staff.buildNormal(name, id, img_url, projectId);
        return staffServiceI.edit(staff);

    }

    @RequestMapping("delStaff")
    @ResponseBody
    public Object del(@RequestParam(value = "id") int id) {

        return staffServiceI.del(id);

    }


}
