package com.test.controller;

import com.test.service.project.Project;
import com.test.service.project.ProjectServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/Project")
public class ProjectController {

    @Autowired
    ProjectServiceI projectServiceI;

    @RequestMapping("getProjectList")
    @ResponseBody
    public Object getProjectList() {

        return projectServiceI.getProjectList();

    }

    @RequestMapping("getObjectById")
    @ResponseBody
    public Object getObjectById(@RequestParam(value = "id") int id) {

        Map
                <Object, Object> params = new HashMap
                <Object, Object>();
        params.put("id", id);

        return projectServiceI
                .getProjectByParam(params);

    }

    @RequestMapping("addProject")
    @ResponseBody
    public Object add(@RequestParam(value = "project_name") String project_name, @RequestParam(value = "project_key") String project_key) throws ParseException {

        Project project = Project.buildWithOutId(project_name, project_key);
        return projectServiceI.add(project);

    }

    @RequestMapping("editProject")
    @ResponseBody
    public Object edit(@RequestParam(value = "id") int id, @RequestParam(value = "project_name") String project_name, @RequestParam(value = "project_key") String project_key) throws ParseException {

        Project project = Project.buildNormal(id, project_name, project_key);
        return projectServiceI.edit(project);

    }

    @RequestMapping("delProject")
    @ResponseBody
    public Object del(@RequestParam(value = "id") int id) {

        return projectServiceI.del(id);

    }


}
