package com.test.controller;

import com.test.service.staff.Staff;
import com.test.service.staff.StaffServiceI;
import com.test.service.user.User;
import com.test.service.user.UserServiceI;
import com.test.util.ImageUtil;
import com.test.util.JsonUtil;
import com.test.util.RedmineUtil;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpSession;
import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/User")
public class UserController {

    @Autowired
    UserServiceI userServiceI;

    @Autowired
    StaffServiceI staffServiceI;

    @RequestMapping("getUserList")
    @ResponseBody
    public Object getUserList() {

        return userServiceI.getUserList();

    }

    @RequestMapping("getObjectById")
    @ResponseBody
    public Object getObjectById(@RequestParam(value = "id") int id) {

        Map
                <Object, Object> params = new HashMap
                <Object, Object>();
        params.put("id", id);

        return userServiceI
                .getUserByParam(params);

    }

    @RequestMapping("addUser")
    @ResponseBody
    public Object add(@RequestParam(value = "redmineId") int redmineId, @RequestParam(value = "img_url") String img_url, @RequestParam(value = "name") String name, @RequestParam(value = "projectId") String projectId, @RequestParam(value = "email") String email, @RequestParam(value = "username") String username) throws ParseException {

        User user = User.buildWithOutId(redmineId, img_url, name, projectId, email, username);
        return userServiceI.add(user);

    }

    @RequestMapping("editUser")
    @ResponseBody
    public Object edit(@RequestParam(value = "redmineId") int redmineId, @RequestParam(value = "img_url") String img_url, @RequestParam(value = "name") String name, @RequestParam(value = "id") int id, @RequestParam(value = "projectId") String projectId, @RequestParam(value = "email") String email, @RequestParam(value = "username") String username) throws ParseException {

        User user = User.buildNormal(redmineId, img_url, name, id, projectId, email, username);
        return userServiceI.edit(user);

    }

    @RequestMapping("delUser")
    @ResponseBody
    public Object del(@RequestParam(value = "id") int id) {

        return userServiceI.del(id);

    }

    /**
     * 登陆操作，并且将用户信息存放在session里
     *
     * @param username
     * @param password
     * @param httpSession
     * @return
     */
    @RequestMapping("login")
    public Object login(@RequestParam(value = "username") String username, @RequestParam(value = "password") String password, HttpSession httpSession) {
        try {

            com.taskadapter.redmineapi.bean.User redmineUser = RedmineUtil.checkAuth(username, password);

            if (redmineUser != null) {

                //如果数据库没有，则加用户数据到数据库
                Map<Object, Object> paramUser = new HashMap<>();
                paramUser.put("username", username);

                String name = redmineUser.getLastName() + redmineUser.getFirstName();

                if (userServiceI.getUserByParam(paramUser).size() < 1) {
                    User user = User.buildNormal(redmineUser.getId(), ImageUtil.getRandomImage(), name, -1, "", redmineUser.getMail(), redmineUser.getLogin());
                    userServiceI.add(user);
                }

                //如果没有数据，添加到Staff数据库
                Map<Object, Object> paramStaff = new HashMap<>();
                paramStaff.put("name", name);

                if (staffServiceI.getStaffByParam(paramStaff).size() < 1) {
                    Staff staff = Staff.buildNormal(name, -1, ImageUtil.getRandomImage(), "-1");
                    staffServiceI.add(staff);
                }

                //将User信息保存在session里面
                User user = userServiceI.getUserByParam(paramUser).get(0);
                httpSession.setAttribute("userInfo", user);

                //过期时间为30分钟
                httpSession.setMaxInactiveInterval(60 * 30);

                return "redirect:/resources/index.html";
            } else {
                return "redirect:/resources/login.html";
            }
        } catch (ParseException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 获得当前Session的用户信息
     *
     * @param httpSession
     * @return
     */
    @RequestMapping("getCurrentUserInfo")
    @ResponseBody
    public Object getCurrentUserInfo(HttpSession httpSession) {
        User user = (User) httpSession.getAttribute("userInfo");
        if (user != null) {
            Map<Object, Object> param = new HashMap<>();
            param.put("user", user);
            return JsonUtil.buildStandardJson(param);
        } else
            return JsonUtil.buildFailJson();
    }

    /**
     * 登出并且清空Session信息
     *
     * @param httpSession
     * @return
     */
    @RequestMapping("logout")
    public Object logout(HttpSession httpSession) {
        httpSession.removeAttribute("userInfo");
        return "redirect:/resources/login.html";
    }


}
