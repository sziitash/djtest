package com.test.controller;

import com.test.util.FileUtil;
import com.test.util.JsonUtil;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/File")
public class FileController {

    static Logger log = Logger.getLogger(FileController.class.getName());

    @RequestMapping("OverviewFile")
    @ResponseBody
    public Object getCampaign_prize_winner_listList()
            throws UnsupportedEncodingException {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("fileList", FileUtil.readFile(FileUtil.fileDirName));
        log.info("正在扫描文件中...");
        return JsonUtil.buildStandardJson(params);
    }

    @RequestMapping("getFileContent")
    @ResponseBody
    public Object getFileContent(
            @RequestParam(value = "fileName") String fileName) {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("fileContent",
                FileUtil.txt2String(FileUtil.fileDirPath + fileName));
        return JsonUtil.buildStandardJson(params);
    }

    @RequestMapping("saveContent")
    @ResponseBody
    public Object saveFile(@RequestParam(value = "fileName") String fileName,
                           @RequestParam(value = "fileContent") String fileContent) {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("result",
                FileUtil.saveFile(FileUtil.fileDirPath + fileName, fileContent));
        return JsonUtil.buildStandardJson(params);
    }

    @RequestMapping("newFile")
    @ResponseBody
    public Object newFile(@RequestParam(value = "fileName") String fileName) {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("result", String.valueOf(FileUtil
                .newFile(FileUtil.fileDirPath + fileName)));
        return JsonUtil.buildStandardJson(params);
    }

    @RequestMapping("deleteFile")
    @ResponseBody
    public Object deleteFile(@RequestParam(value = "fileName") String fileName) {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put(
                "result",
                String.valueOf(FileUtil.deleteFile(FileUtil.fileDirPath
                        + fileName)));
        return JsonUtil.buildStandardJson(params);
    }

    @RequestMapping("test")
    @ResponseBody
    public Object test() {
        Map<Object, Object> params = new HashMap<Object, Object>();
        params.put("result", "what's that!");
        log.debug("debug Test");
        return JsonUtil.buildStandardJson(params);
    }

}
