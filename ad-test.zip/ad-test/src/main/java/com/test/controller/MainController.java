package com.test.controller;

import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.bean.Issue;
import com.taskadapter.redmineapi.bean.Version;
import com.test.service.project.Project;
import com.test.service.project.ProjectServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.SimpleDateFormat;
import java.util.*;

/**
 * Created by sjj on 2015/10/24 0024.
 */
@Controller
public class MainController {

    @Autowired
    private ProjectServiceI projectServiceI;

    private final static String username = "Auto_AppDistribute";
    private final static String password = "H2NZTnVmgR";
    private RedmineManager rm = new RedmineManager("http://api.redmine.meizu.com/", username, password);
    private Map<String, String> queryMap;
    private Map<String, Object> resultMap;
    private Map<String, Object> lastResult;


    @ResponseBody
    @RequestMapping(value = "taskinfo/{taskid}", method = RequestMethod.GET)
    public Map<String, Object> getTaskInfo(@PathVariable("taskid") Integer taskid) throws Exception {
        Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
        List<Object> taskList = new LinkedList<Object>();
        Issue taskinfo = rm.getIssueById(taskid);
        Map<String, Object> taskInfo = new LinkedHashMap<String, Object>();
        taskInfo.put("id", taskinfo.getId());
        taskInfo.put("name", taskinfo.getSubject());
        taskInfo.put("stat", taskinfo.getStatusName());
        taskInfo.put("priority", taskinfo.getPriorityText());
        try {
            taskInfo.put("category", taskinfo.getTargetVersion().getName());
        } catch (Exception e) {
            taskInfo.put("category", "#");
        }
        try {
            taskInfo.put("startdate", stampToDate(String.valueOf(taskinfo.getStartDate().getTime())));
        } catch (Exception e) {
            taskInfo.put("startdate", "#");
        }
        try {
            taskInfo.put("duedate", stampToDate(String.valueOf(taskinfo.getDueDate().getTime())));
        } catch (Exception e) {
            taskInfo.put("duedate", "#");
        }
        taskInfo.put("trackid", taskinfo.getTracker().getId());
        taskInfo.put("ratio", String.valueOf(taskinfo.getDoneRatio()));
        taskInfo.put("author", taskinfo.getAuthor().getFirstName());
        taskInfo.put("assignee", taskinfo.getAssignee().getFirstName());
        taskList.add(taskInfo);
        resultMap.put("data", taskList);
//        resultMap.put("name","hello");
        return resultMap;
    }

    @ResponseBody
    @RequestMapping(value = "tasklist/{projectid}")
    public Map<String, Object> getTaskList(@PathVariable("projectid") Integer projectid) throws Exception {
        Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
        List<Object> taskList = new LinkedList<Object>();
        //redmine条件查询
        List<Project> projects = projectServiceI.getProjectList();
        for (Project project : projects) {
            if (projectid == project.getId() && !project.getProject_name().equals("应用分发资源池")) {
                return getTaksList(project.getProject_key(), projectid);
            }
        }
        return null;
    }

    @ResponseBody
    @RequestMapping(value = "taskbuglist/{taskid}")
    public Map<String, Object> getTaskBugList(@PathVariable("taskid") Integer taskid) throws RedmineException {
        Map<String, Object> lastResult = new LinkedHashMap<String, Object>();
        List<Object> resultList = new LinkedList<Object>();
        Issue task = rm.getIssueById(taskid);
        int trackerid = task.getTracker().getId();
        int projectid = task.getProject().getId();
        if (trackerid == 12) {
            Map<String, String> queryParam = new HashMap<String, String>();
            queryParam.put("set_filter", "1");
            queryParam.put("project_id", String.valueOf(projectid));
            queryParam.put("f[]","parent_id");
            queryParam.put("op[parent_id]", "=");
            queryParam.put("v[parent_id][]", String.valueOf(taskid));
            List<Issue> issues = rm.getIssues(queryParam);
            if (issues.size() == 0) {
                lastResult.put("data", resultList);
                return lastResult;
            }
            int relatesid = issues.get(0).getId();
            getResultList(resultList, projectid, relatesid);
        } else {
            getResultList(resultList, projectid, taskid);
        }
        lastResult.put("data", resultList);

        return lastResult;
    }

    @ResponseBody
    @RequestMapping(value = "versions/{projectkey}")
    public Map<String, Object> getVersionByProjectkey(
            @PathVariable("projectkey") String projectkey) throws Exception {
        Map<String,Object> result = new HashMap<>();
        int projectid = rm.getProjectByKey(projectkey).getId();
        List<Version> versions = rm.getVersions(projectid);
        List<Map<String,Object>> verList = new LinkedList<>();
        for(Version ver:versions){
            if(!ver.getStatus().equals("closed")){
                Map<String,Object> resultMap = new LinkedHashMap<>();
                resultMap.put("versionId",ver.getId());
                resultMap.put("name",ver.getName());
                resultMap.put("status",ver.getStatus());
                resultMap.put("starttime",stampToDate(ver.getCreatedOn().getTime()));
                if(ver.getDueDate()==null){
                    resultMap.put("endtime","#");
                }
                else {
                    resultMap.put("endtime",stampToDate(ver.getDueDate().getTime()));
                }
                verList.add(resultMap);
            }
        }
        listSort(verList,"versionId");
        result.put("data",verList);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "versionlist/{versionId}")
    public Map<String, Object> getTaskByVersionId(
            @PathVariable("versionId") int versionId) throws Exception {
        Map<String,Object> result = new HashMap<>();
        String versionName = rm.getVersionById(versionId).getName();
        //根据“跟踪版本”字段查找
        List<Map<String, Object>> gettracks =
                getTaskbyIteration(versionId,"tracked_version");
        //根据“目标版本”字段查找
        List<Map<String, Object>> getfixeds =
                getTaskbyIteration(versionId,"fixed_version_id");
        gettracks.addAll(getfixeds);
        HashSet hashSet = new HashSet(gettracks);
        gettracks.clear();
        gettracks.addAll(hashSet);
        listSort(gettracks,"id");
        result.put("name",versionName);
        result.put("data",gettracks);
        return result;
    }

    @ResponseBody
    @RequestMapping(value = "issueInfo/{issueId}")
    public Issue getIssueInfo(@PathVariable("issueId") int issueId) throws RedmineException {
//        Map<String,Object> result = new HashMap<>();
        Issue x = rm.getIssueById(issueId);
        return x;
    }

    private static String stampToDate(String s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        long lt = new Long(s);
        Date date = new Date(lt);
        res = simpleDateFormat.format(date);
        return res;
    }

    private Map<String, Object> getTaksList(String projectkey, Integer projectid) throws RedmineException {
        //根据project_id和测试单类型查找对应测试单
        lastResult = new HashMap<String, Object>();
        List<Object> resultList = new LinkedList();
        queryMap = new HashMap<String, String>();
        queryMap.put("set_filter", "1");
        queryMap.put("project_id", projectkey);
        queryMap.put("f[]", "tracker_id");
        queryMap.put("op[tracker_id]", "=");
        queryMap.put("v[tracker_id][]", "12");
        List<Issue> result = rm.getIssues(queryMap,0,30);
        for (Issue issueinfo : result) {
            resultMap = new LinkedHashMap<String, Object>();
            int bugid = issueinfo.getId();
            resultMap.put("id", bugid);
            Integer stat = issueinfo.getStatusId();
            switch (stat) {
                case 1:
                    resultMap.put("status", "new");
                    break;
                case 2:
                    resultMap.put("status", "work");
                    break;
                default:
                    resultMap.put("status", "done");
            }
            if (issueinfo.getAssignee() != null)
                resultMap.put("text", issueinfo.getSubject() + "*【" + issueinfo.getAssignee().getFirstName() + "】");
            else
                resultMap.put("text", issueinfo.getSubject());
            resultMap.put("tag", "测试任务");
            Integer priorityid = issueinfo.getPriorityId();
            switch (priorityid) {
                case 1:
                    resultMap.put("color", "green");
                    break;
                case 2:
                    resultMap.put("color", "grey");
                    break;
                case 3:
                    resultMap.put("color", "#CC9933");
                    break;
                case 4:
                    resultMap.put("color", "red");
                    break;
            }
            resultMap.put("personId", issueinfo.getAuthor().getId());
            if (issueinfo.getAssignee() != null) {
                resultMap.put("assigneeId", issueinfo.getAssignee().getId());
                resultMap.put("assigneeName", issueinfo.getAssignee().getFirstName());
            }
            resultMap.put("projectId", projectid);
            resultMap.put("$index", bugid);
            resultMap.put("textarea", "");
            try {
                resultMap.put("start_time", stampToDate(String.valueOf(issueinfo.getStartDate().getTime())));
            } catch (Exception e) {
                resultMap.put("start_time", "#");
            }
            try {
                resultMap.put("end_time", stampToDate(String.valueOf(issueinfo.getDueDate().getTime())));
            } catch (Exception e) {
                resultMap.put("end_time", "#");
            }
            resultMap.put("source", "redmine");
            resultMap.put("comments", "0");
            try {
                resultMap.put("category", issueinfo.getTargetVersion().getName());
            } catch (Exception e) {
                resultMap.put("category", "#");
            }

            resultList.add(resultMap);
        }
        lastResult.put("data", resultList);

        return lastResult;
    }

    private void getResultList(List<Object> resultList, int projectid, int taskid) throws RedmineException {
        Map<String, String> queryParam1 = new LinkedHashMap<String, String>();
        queryParam1.put("set_filter", "1");
        queryParam1.put("project_id", String.valueOf(projectid));
        queryParam1.put("f[]", "relates");
        queryParam1.put("op[relates]", "=");
        queryParam1.put("v[relates][]", String.valueOf(taskid));
        List<Issue> issues1 = rm.getIssues(queryParam1);
        for (Issue issue : issues1) {
            if(issue.getTracker().getId()==16 || issue.getTracker().getId()==30){
                Map<String, Object> resultMap = new LinkedHashMap<String, Object>();
                resultMap.put("id", issue.getId());
                resultMap.put("title", issue.getSubject());
                resultMap.put("stat", issue.getStatusName());
                resultMap.put("priority", issue.getPriorityText());
                resultMap.put("creater", issue.getAuthor().getFirstName());
                resultMap.put("assigneer", issue.getAssignee().getFirstName());
                resultMap.put("createdate", stampToDate(issue.getCreatedOn().getTime()));
                resultList.add(resultMap);
            }
        }
    }

    private List<Map<String,Object>> getTaskbyIteration(int versionId,String type){
        List<Issue> issuesList;
        Map<String,String> queryMap = new HashMap<String, String>();
        queryMap.put("set_filter", "1");
        queryMap.put("f[]", type);
        queryMap.put("op["+type+"]", "=");
        queryMap.put("v["+type+"][]", String.valueOf(versionId));
        try{
            issuesList = rm.getIssues(queryMap);
        }
        catch (Exception e){
            issuesList = new ArrayList<>();
        }
        List<Map<String,Object>> results = new LinkedList<>();
        for(Issue issue:issuesList){
            if(issue.getTracker().getId()==12){
                Map<String,Object> taskList = new LinkedHashMap<>();
                taskList.put("id",issue.getId());
                taskList.put("name",issue.getSubject());
                try {
                    taskList.put("assignee",issue.getAssignee().getFirstName());
                }
                catch (Exception e){
                    taskList.put("assignee","#");
                }
                if(issue.getStartDate()==null){
                    taskList.put("starttime","#");
                }
                else {
                    taskList.put("starttime",stampToDate(issue.getStartDate().getTime()));
                }
                if(issue.getDueDate()==null){
                    taskList.put("endtime","#");
                }
                else {
                    taskList.put("endtime",stampToDate(issue.getDueDate().getTime()));
                }
                results.add(taskList);
            }
        }
        return results;
    }

    private static String stampToDate(long s) {
        String res;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date date = new Date(s);
        res = simpleDateFormat.format(date);
        return res;
    }


    private static void listSort(List<Map<String,Object>> resultList, final String sorter) throws Exception{
        // resultList是需要排序的list，其内放的是Map
        // 返回的结果集
        Collections.sort(resultList,new Comparator<Map<String,Object>>() {
            public int compare(Map<String, Object> o1,Map<String, Object> o2) {
                //o1，o2是list中的Map，可以在其内取得值，按其排序，此例为升序，s1和s2是排序字段值
                Integer s1 = (Integer) o1.get(sorter);
                Integer s2 = (Integer) o2.get(sorter);

                if(s1>s2) {
                    return -1;
                }else {
                    return 1;
                }
            }
        });
    }
}