package com.test.controller;

import com.test.service.iteration.Iteration;
import com.test.service.iteration.IterationServiceI;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.text.ParseException;
import java.util.HashMap;
import java.util.Map;

@Controller
@RequestMapping("/Iteration")
public class IterationController {

    @Autowired
    IterationServiceI iterationServiceI;

    @RequestMapping("getIterationList")
    @ResponseBody
    public Object getIterationList() {

        return iterationServiceI.getIterationList();

    }

    @RequestMapping("getObjectById")
    @ResponseBody
    public Object getObjectById(@RequestParam(value = "id") int id) {

        Map
                <Object, Object> params = new HashMap
                <Object, Object>();
        params.put("id", id);

        return iterationServiceI
                .getIterationByParam(params);

    }

    @RequestMapping("addIteration")
    @ResponseBody
    public Object add(@RequestParam(value = "redmineversion") int redmineversion, @RequestParam(value = "stat") int stat) throws ParseException {

        Iteration iteration = Iteration.buildWithOutId(redmineversion, stat);
        return iterationServiceI.add(iteration);

    }

    @RequestMapping("editIteration")
    @ResponseBody
    public Object edit(@RequestParam(value = "redmineversion") int redmineversion, @RequestParam(value = "stat") int stat, @RequestParam(value = "id") int id) throws ParseException {

        Iteration iteration = Iteration.buildNormal(redmineversion, stat, id);
        return iterationServiceI.edit(iteration);

    }

    @RequestMapping("delIteration")
    @ResponseBody
    public Object del(@RequestParam(value = "id") int id) {

        return iterationServiceI.del(id);

    }


}
