package com.test.service.iteration;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IterationServiceImpl implements IterationServiceI {

	@Autowired
	IterationDaoI iterationDaoI;

	@Override
	public List<Iteration> getIterationList() {
		return iterationDaoI.getIterationList();
	}
	
	@Override
	public List<Iteration> getIterationByParam(
			Map<Object, Object> params) {
		return iterationDaoI.getIterationByParam(params);
	}

	@Override
	public boolean add(Iteration iteration) {
		return iterationDaoI.add(iteration);
	}

	@Override
	public boolean edit(Iteration iteration) {
		return iterationDaoI.edit(iteration);
	}

	@Override
	public boolean del(int id) {
		return iterationDaoI.del(id);
	}

}

