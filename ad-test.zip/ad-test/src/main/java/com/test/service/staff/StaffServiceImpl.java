package com.test.service.staff;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class StaffServiceImpl implements StaffServiceI {

	@Autowired
	StaffDaoI staffDaoI;

	@Override
	public List<Staff> getStaffList() {
		return staffDaoI.getStaffList();
	}
	
	@Override
	public List<Staff> getStaffByParam(
			Map<Object, Object> params) {
		return staffDaoI.getStaffByParam(params);
	}

	@Override
	public boolean add(Staff staff) {
		return staffDaoI.add(staff);
	}

	@Override
	public boolean edit(Staff staff) {
		return staffDaoI.edit(staff);
	}

	@Override
	public boolean del(int id) {
		return staffDaoI.del(id);
	}

}

