package com.test.service.staff;

import java.util.List;
import java.util.Map;

public interface StaffServiceI {
	
	List<Staff> getStaffList();
	
	List<Staff> getStaffByParam(
			Map<Object, Object> params);

	boolean add(Staff staff);

	boolean edit(Staff staff);

	boolean del(int id);
}

