package com.test.service.user;

import java.util.List;
import java.util.Map;

public interface UserServiceI {
	
	List<User> getUserList();
	
	List<User> getUserByParam(
			Map<Object, Object> params);

	boolean add(User user);

	boolean edit(User user);

	boolean del(int id);
}

