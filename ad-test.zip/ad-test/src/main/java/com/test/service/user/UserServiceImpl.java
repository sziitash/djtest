package com.test.service.user;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserServiceI {

	@Autowired
	UserDaoI userDaoI;

	@Override
	public List<User> getUserList() {
		return userDaoI.getUserList();
	}
	
	@Override
	public List<User> getUserByParam(
			Map<Object, Object> params) {
		return userDaoI.getUserByParam(params);
	}

	@Override
	public boolean add(User user) {
		return userDaoI.add(user);
	}

	@Override
	public boolean edit(User user) {
		return userDaoI.edit(user);
	}

	@Override
	public boolean del(int id) {
		return userDaoI.del(id);
	}

}

