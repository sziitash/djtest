package com.test.service.project;

import java.util.List;
import java.util.Map;

public interface ProjectServiceI {

    List<Project> getProjectList();

    List<Project> getProjectByParam(
            Map<Object, Object> params);

    boolean add(Project project);

    boolean edit(Project project);

    boolean del(int id);
}

