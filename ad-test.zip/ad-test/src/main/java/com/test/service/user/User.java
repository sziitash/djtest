package com.test.service.user;

    import java.util.Date;

import java.text.ParseException;
import java.text.SimpleDateFormat;

public class User {

private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private Date create_time;
    private int redmineId;
    private String img_url;
    private String name;
    private Date lmodify;
    private int id;
    private String projectId;
    private String email;
    private String username;

    public Date getCreate_time() {
    return create_time;
    }
    public void setCreate_time(Date create_time) {
    this.create_time = create_time;
    }
    public int getRedmineId() {
    return redmineId;
    }
    public void setRedmineId(int redmineId) {
    this.redmineId = redmineId;
    }
    public String getImg_url() {
    return img_url;
    }
    public void setImg_url(String img_url) {
    this.img_url = img_url;
    }
    public String getName() {
    return name;
    }
    public void setName(String name) {
    this.name = name;
    }
    public Date getLmodify() {
    return lmodify;
    }
    public void setLmodify(Date lmodify) {
    this.lmodify = lmodify;
    }
    public int getId() {
    return id;
    }
    public void setId(int id) {
    this.id = id;
    }
    public String getProjectId() {
    return projectId;
    }
    public void setProjectId(String projectId) {
    this.projectId = projectId;
    }
    public String getEmail() {
    return email;
    }
    public void setEmail(String email) {
    this.email = email;
    }
    public String getUsername() {
    return username;
    }
    public void setUsername(String username) {
    this.username = username;
    }

public static User buildNormal(int redmineId,String img_url,String name,int id,String projectId,String email,String username) throws ParseException{
User user = new User();
    user.setCreate_time(df.parse(df.format(new Date())));
    user.setRedmineId(redmineId);
    user.setImg_url(img_url);
    user.setName(name);
    user.setLmodify(df.parse(df.format(new Date())));
    user.setId(id);
    user.setProjectId(projectId);
    user.setEmail(email);
    user.setUsername(username);
return user;
}

public static User buildWithOutId(int redmineId,String img_url,String name,String projectId,String email,String username) throws ParseException{
User user = new User();
    user.setCreate_time(df.parse(df.format(new Date())));
    user.setRedmineId(redmineId);
    user.setImg_url(img_url);
    user.setName(name);
    user.setLmodify(df.parse(df.format(new Date())));
    user.setProjectId(projectId);
    user.setEmail(email);
    user.setUsername(username);
return user;
}
}



