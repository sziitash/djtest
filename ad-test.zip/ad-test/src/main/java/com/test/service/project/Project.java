package com.test.service.project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Project {

    private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private Date lmodify;
    private int id;
    private Date create_time;
    private String project_name;
    private String project_key;

    public Date getLmodify() {
        return lmodify;
    }

    public void setLmodify(Date lmodify) {
        this.lmodify = lmodify;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.create_time = create_time;
    }

    public String getProject_name() {
        return project_name;
    }

    public void setProject_name(String project_name) {
        this.project_name = project_name;
    }

    public String getProject_key() {
        return project_key;
    }

    public void setProject_key(String project_key) {
        this.project_key = project_key;
    }

    public static Project buildNormal(int id, String project_name, String project_key) throws ParseException {
        Project project = new Project();
        project.setLmodify(df.parse(df.format(new Date())));
        project.setId(id);
        project.setCreate_time(df.parse(df.format(new Date())));
        project.setProject_name(project_name);
        project.setProject_key(project_key);
        return project;
    }

    public static Project buildWithOutId(String project_name, String project_key) throws ParseException {
        Project project = new Project();
        project.setLmodify(df.parse(df.format(new Date())));
        project.setCreate_time(df.parse(df.format(new Date())));
        project.setProject_name(project_name);
        project.setProject_key(project_key);
        return project;
    }
}



