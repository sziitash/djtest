package com.test.service.staff;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

@Repository
public class StaffDaoImpl extends JdbcDaoSupport implements
		StaffDaoI {

	private static final String TableName = "staff";
	private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

	@Autowired
	public void setJB(JdbcTemplate jdbcTemplate) {
		super.setJdbcTemplate(jdbcTemplate);
	}

	@Override
	public List<Staff> getStaffList() {

		String sql = "SELECT * FROM " + TableName;

		return getJdbcTemplate().query(sql,
				new BeanPropertyRowMapper<>(Staff.class));
	}
	
	@Override
	public List<Staff> getStaffByParam(
			Map<Object, Object> params) {

		if (params == null) {
			return null;
		}

		String sqlWhere = " WHERE ";
		List<Object> param = new ArrayList<>();
		for (Object key : params.keySet()) {
			sqlWhere += key + "=" + "? AND ";
			param.add(params.get(key));
		}

		sqlWhere = sqlWhere.substring(0, sqlWhere.length() - 4);

		String sql = "SELECT * FROM " + TableName + sqlWhere;

		return getJdbcTemplate().query(sql, param.toArray(),
				new BeanPropertyRowMapper<>(Staff.class));
	}

    @Override
    public boolean add(Staff staff) {
    	String sql = "insert into `" + TableName + "` (`name`, `img_url`, `projectId`) values (?, ?, ?)";

    	List<Object> params = new ArrayList<>();
		params.add(staff.getName());
		params.add(staff.getImg_url());
		params.add(staff.getProjectId());

        return getJdbcTemplate().update(sql, params.toArray()) == 1;

	}

	@Override
	public boolean edit(Staff staff) {
        String sql = "UPDATE `" + TableName + "` SET `name` = ?, `img_url` = ?, `projectId` = ? WHERE `id` = ?";
        List<Object> params = new ArrayList<>();
			params.add(staff.getName());
			params.add(staff.getImg_url());
			params.add(staff.getProjectId());
			params.add(staff.getId());
            return getJdbcTemplate().update(sql, params.toArray()) == 1;
		}

	@Override
	public boolean del(int id) {
		String sql = "DELETE FROM `" + TableName + "` WHERE id = ?";
		List<Object> params = new ArrayList<>();
		params.add(id);
		return getJdbcTemplate().update(sql, params.toArray()) == 1;
	}

}
