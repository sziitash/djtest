package com.test.service.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class ProjectServiceImpl implements ProjectServiceI {

    @Autowired
    ProjectDaoI projectDaoI;

    @Override
    public List<Project> getProjectList() {
        return projectDaoI.getProjectList();
    }

    @Override
    public List<Project> getProjectByParam(
            Map<Object, Object> params) {
        return projectDaoI.getProjectByParam(params);
    }

    @Override
    public boolean add(Project project) {
        return projectDaoI.add(project);
    }

    @Override
    public boolean edit(Project project) {
        return projectDaoI.edit(project);
    }

    @Override
    public boolean del(int id) {
        return projectDaoI.del(id);
    }

}

