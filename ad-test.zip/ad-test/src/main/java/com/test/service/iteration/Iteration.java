package com.test.service.iteration;


import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Iteration {

    private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private int redmineversion;
    private int stat;
    private int id;

    public int getRedmineversion() {
        return redmineversion;
    }

    public void setRedmineversion(int redmineversion) {
        this.redmineversion = redmineversion;
    }

    public int getStat() {
        return stat;
    }

    public void setStat(int stat) {
        this.stat = stat;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public static Iteration buildNormal(int redmineversion, int stat, int id) throws ParseException {
        Iteration iteration = new Iteration();
        iteration.setRedmineversion(redmineversion);
        iteration.setStat(stat);
        iteration.setId(id);
        return iteration;
    }

    public static Iteration buildWithOutId(int redmineversion, int stat) throws ParseException {
        Iteration iteration = new Iteration();
        iteration.setRedmineversion(redmineversion);
        iteration.setStat(stat);
        return iteration;
    }
}



