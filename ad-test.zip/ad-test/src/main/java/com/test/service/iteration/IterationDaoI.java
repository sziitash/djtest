package com.test.service.iteration;

import java.util.List;
import java.util.Map;

public interface IterationDaoI {

	List<Iteration> getIterationList();
	
	List<Iteration> getIterationByParam(
			Map<Object, Object> params);

	boolean add(Iteration iteration);

	boolean edit(Iteration iteration);

	boolean del(int id);
}
