package com.test.service.staff;


import java.text.ParseException;
import java.text.SimpleDateFormat;

public class Staff {

    private static final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    private String name;
    private int id;
    private String img_url;
    private String projectId;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getImg_url() {
        return img_url;
    }

    public void setImg_url(String img_url) {
        this.img_url = img_url;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public static Staff buildNormal(String name, int id, String img_url, String projectId) throws ParseException {
        Staff staff = new Staff();
        staff.setName(name);
        staff.setId(id);
        staff.setImg_url(img_url);
        staff.setProjectId(projectId);
        return staff;
    }

    public static Staff buildWithOutId(String name, String img_url, String projectId) throws ParseException {
        Staff staff = new Staff();
        staff.setName(name);
        staff.setImg_url(img_url);
        staff.setProjectId(projectId);
        return staff;
    }
}



