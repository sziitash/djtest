package com.test.service.project;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

@Repository
public class ProjectDaoImpl extends JdbcDaoSupport implements
        ProjectDaoI {

    private static final String TableName = "project";
    private SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    @Autowired
    public void setJB(JdbcTemplate jdbcTemplate) {
        super.setJdbcTemplate(jdbcTemplate);
    }

    @Override
    public List<Project> getProjectList() {

        String sql = "SELECT * FROM " + TableName;

        return getJdbcTemplate().query(sql,
                new BeanPropertyRowMapper<>(Project.class));
    }

    @Override
    public List<Project> getProjectByParam(
            Map
                    <Object, Object> params) {

        if (params == null) {
            return null;
        }

        String sqlWhere = " WHERE ";
        List
                <Object> param = new ArrayList<>();
        for (Object key : params.keySet()) {
            sqlWhere += key + "=" + "? AND ";
            param.add(params.get(key));
        }

        sqlWhere = sqlWhere.substring(0, sqlWhere.length() - 4);

        String sql = "SELECT * FROM " + TableName + sqlWhere;

        return getJdbcTemplate().query(sql, param.toArray(),
                new BeanPropertyRowMapper<>(Project.class));
    }

    @Override
    public boolean add(Project project) {
        String sql = "insert into `" + TableName + "` (`lmodify`, `create_time`, `project_name`, `project_key`) values (?, ?, ?, ?)";

        List
                <Object> params = new ArrayList<>();
        params.add(df.format(new Date()));
        params.add(df.format(new Date()));
        params.add(project.getProject_name());
        params.add(project.getProject_key());

        return getJdbcTemplate().update(sql, params.toArray()) == 1;

    }

    @Override
    public boolean edit(Project project) {
        String sql = "UPDATE `" + TableName + "` SET `lmodify` = ?, `create_time` = ?, `project_name` = ?, `project_key` = ? WHERE `id` = ?";
        List
                <Object> params = new ArrayList<>();
        params.add(df.format(new Date()));
        params.add(df.format(new Date()));
        params.add(project.getProject_name());
        params.add(project.getProject_key());
        params.add(project.getId());
        return getJdbcTemplate().update(sql, params.toArray()) == 1;
    }

    @Override
    public boolean del(int id) {
        String sql = "DELETE FROM `" + TableName + "` WHERE id = ?";
        List
                <Object> params = new ArrayList<>();
        params.add(id);
        return getJdbcTemplate().update(sql, params.toArray()) == 1;
    }

}
