package com.test.util;

public class JsonUtil {

    private String code;
    private Object data;

    public JsonUtil(String code, Object data) {
        this.code = code;
        this.data = data;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }
 
    public Object getData() {
        return data;
    }

    public void setData(Object data) {
        this.data = data;
    }

    public static JsonUtil buildStandardJson(Object data) {
        return new JsonUtil("200", data);
    }

    public static JsonUtil buildFailJson() {
        return new JsonUtil("999", "");
    }

}
