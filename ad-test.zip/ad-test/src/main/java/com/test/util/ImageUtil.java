package com.test.util;

/**
 * 随机获取一个图标
 * Created by wenli on 2017/1/6.
 */
public class ImageUtil {

    private static final String images = "alligator,ant,bat,bear,bee,bull,butterfly,donkey,elephant,wolf";
    private static final int max = images.split(",").length - 1;
    private static final int min = 0;

    public static String getRandomImage() {
        int random = (int) (1 + Math.random() * (max - min + 1));
        return images.split(",")[random] + ".png";
    }
}
