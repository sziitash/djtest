package com.test.util;

import com.taskadapter.redmineapi.RedmineException;
import com.taskadapter.redmineapi.RedmineManager;
import com.taskadapter.redmineapi.bean.User;

/**
 * Created by wenli on 2017/1/4.
 */
public class RedmineUtil {

    @SuppressWarnings("deprecation")
    public static User checkAuth(String username, String password) {
        //RedmineManager redmineManager = RedmineManagerFactory.createWithUserAuth("http://redmine.meizu.com/", username, password);
        RedmineManager redmineManager = new RedmineManager("http://redmine.meizu.com/", username, password);
        User user = null;
        try {
            user = redmineManager.getCurrentUser();
            return user;
        } catch (RedmineException e) {
            return null;
        }
    }
}
