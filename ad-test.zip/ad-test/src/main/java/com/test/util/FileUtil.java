package com.test.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {

	public static final String fileDirName = "/data/jetty/work/jetty-0.0.0.0-8080-static.war-_static-any-/webapp/resources/wiki";
	public static final String fileDirPath = "/data/jetty/work/jetty-0.0.0.0-8080-static.war-_static-any-/webapp/resources/wiki/";

	// public static final String fileDirName =
	// "C:\\Users\\wenli\\Desktop\\大兄弟";
	// public static final String fileDirPath =
	// "C:\\Users\\wenli\\Desktop\\大兄弟\\";

	/**
	 * 
	 * @description: 读取指定文件夹路径下的文件名称
	 * @date: 2016年10月10日 下午4:25:06
	 * @author: wenli
	 * @param filePath
	 * @throws UnsupportedEncodingException
	 */
	public static List<String> readFile(String filePath)
			throws UnsupportedEncodingException {
		File file = new File(filePath);
		List<String> fileLists = new ArrayList<String>();
		if (file.isDirectory()) {
			String[] fileList = file.list();
			for (String fileInstance : fileList) {
				// 不要包含那些奇怪的临时文件
				if (!fileInstance.contains(".s")) {
					fileLists.add(fileInstance);
				}
			}
		} else {
			System.out.println("Not a dir");
		}
		return fileLists;
	}

	/**
	 * 
	 * @description: 读取文件的内容
	 * @date: 2016年10月10日 下午4:25:41
	 * @author: wenli
	 * @param file
	 * @return
	 */
	public static String txt2String(String filePath) {
		File file = new File(filePath);
		StringBuilder result = new StringBuilder();
		BufferedReader br = null;
		try {
			InputStreamReader isr = new InputStreamReader(new FileInputStream(
					file), "UTF-8");
			br = new BufferedReader(isr);// 构造一个BufferedReader类来读取文件
			String s = null;
			while ((s = br.readLine()) != null) {// 使用readLine方法，一次读一行
				result.append(s + System.lineSeparator());
			}

		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				br.close();
			} catch (Exception e2) {
				// TODO: handle exception
				e2.printStackTrace();
			}
		}
		return result.toString();
	}

	/**
	 * 
	 * @description:保存文件内容
	 * @date: 2016年10月13日 上午9:28:28
	 * @author: wenli
	 * @param filePath
	 * @param fileContent
	 * @return
	 */
	public static boolean saveFile(String filePath, String fileContent) {
		FileOutputStream fos = null;
		File f = new File(filePath);
		try {
			if (!f.exists()) {
				// 文件不存在则创建
				f.createNewFile();
			}
			fos = new FileOutputStream(f);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "UTF-8");
			// 写入文件内容
			osw.write(fileContent);
			osw.flush();
			System.out.println(filePath + " 写入成功 ");
			return true;
		} catch (IOException e) {
			System.err.println("文件创建失败");
			return false;
		} finally {
			if (fos != null) {
				try {
					fos.close();
				} catch (IOException e) {
					System.err.println("文件流关闭失败");
				}
			}
		}
	}

	/**
	 * 
	 * @description:创建新文件
	 * @date: 2016年10月13日 上午9:34:46
	 * @author: wenli
	 * @param filePath
	 * @return
	 */
	public static boolean newFile(String filePath) {

		try {
			File file = new File(filePath);
			if (file.exists()) {
				return false;
			} else {
				file.createNewFile();
				return true;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return false;
	}

	public static boolean deleteFile(String filePath) {

		try {
			File file = new File(filePath);
			if (file.exists()
					&& !file.getName().equals("navigation.md")
					&& !txt2String(fileDirPath + "navigation.md").contains(
							file.getName())) {
				file.delete();
				return true;
			} else {
				return false;
			}
		} catch (Exception e) {
			// TODO: handle exception
			e.printStackTrace();
		}

		return false;

	}

	public static void main(String[] args) {
		File file = new File(fileDirPath + "navigation.md");
		System.out.println(file.getName());
		System.out.println(txt2String(fileDirPath + "navigation.md").contains(
				file.getName()));
	}

}
