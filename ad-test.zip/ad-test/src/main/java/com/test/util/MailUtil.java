package com.test.util;

import javax.mail.Session;
import javax.mail.Transport;
import java.util.Properties;

/**
 * Created by wenli on 2017/1/3.
 */
public class MailUtil {

    //check connection with user and password
    public static boolean checkAuth(String user, String password) {

        try {
            //初始化参数
            Properties properties = new Properties();
            properties.setProperty("mail.smtp.auth", "true");
            properties.setProperty("mail.host", "smtp.meizu.com");
            properties.setProperty("mail.transport.protocol", "smtp");

            //设置环境信息
            Session session = Session.getInstance(properties);

            //连接到服务器
            Transport transport = null;
            transport = session.getTransport();
            transport.connect(user, password);
            return transport.isConnected();
        } catch (Exception e) {
            return false;
        }

    }
}
