/**
 * dashboard.js
 * Created by wenli on 2017/1/12.
 */
$(function () {
    $.getJSON("/ad-test/User/getCurrentUserInfo", function (result) {

        if (result.code == "999") {
            $("#taskBoard").attr("src", "http://tm.meizu.com:8008/task?projectId=1");

        } else {

            var userInfo = result.data.user;
            var projectId = null;
            if (userInfo != null)
                projectId = userInfo.projectId.split(",")[0];
            if (projectId != null && projectId != -1)
                $("#taskBoard").attr("src", "http://tm.meizu.com:8008/task?projectId=" + projectId + "&loginName=" + userInfo.username + "&userName=" + userInfo.name + "&userId=" + userInfo.id);
            else
                $("#taskBoard").attr("src", "http://tm.meizu.com:8008/task?projectId=1");
        }
    })
});


