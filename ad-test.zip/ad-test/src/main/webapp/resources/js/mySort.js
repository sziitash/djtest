﻿(function($){
    function getpriorityid(result){
        switch (result){
            case '低':
                return "d";
            case '普通':
                return "c";
            case '高':
                return "b";
            default:
                return "a";
        }
    }
    function getstatid(result){
            switch (result){
                case '新建':
                    return "a";
                case '已解决':
                    return "b";
                case '已验证':
                    return "c";
                default:
                    return "d";
            }
        }
	//插件
	$.extend($,{
		//命名空间
		sortTable:{
			sort:function(tableId,Idx){
				var table = document.getElementById(tableId);
				var tbody = table.tBodies[0];
				var tr = tbody.rows; 
		
				var trValue = new Array();
				for (var i=0; i<tr.length; i++ ) {
					trValue[i] = tr[i];  //将表格中各行的信息存储在新建的数组中
				}

				if (tbody.sortCol == Idx) {
					trValue.reverse(); //如果该列已经进行排序过了，则直接对其反序排列
				} else {
			        trValue.sort(function(tr1,tr2){
			            var value1 = tr1.cells[Idx].innerHTML;
			            var value2 = tr2.cells[Idx].innerHTML;
			            if(Idx==2){
			                var statid1 = getstatid(value1);
                            var statid2 = getstatid(value2);
                            return statid1.localeCompare(statid2);
			            }
			            else if(Idx==3){
                            var priorityid1 = getpriorityid(value1);
                            var priorityid2 = getpriorityid(value2);
                            return priorityid1.localeCompare(priorityid2);
			            }
			            else{
			                return value1.localeCompare(value2);
			            }
                    });
                    //console.log(trValue.length);
                    //console.log(resultList.length);
//				    var lastarray = new Array();
////					//trValue.sort(compareTrs(Idx));  //进行排序
//                    for(var x=0;x<sortList.length;x++){
//                        for(var z = 0;z < resultList.length;z++){
//                            var htmlstr = resultList[z];
//                            if(htmlstr==sortList[x]){
//                                lastarray.push(htmlstr);
//                            }
//                        }
//                    }
				}

				var fragment = document.createDocumentFragment();  //新建一个代码片段，用于保存排序后的结果
				for (var i=0; i<trValue.length; i++ ) {
					fragment.appendChild(trValue[i]);
				}
				tbody.appendChild(fragment); //将排序的结果替换掉之前的值
				tbody.sortCol = Idx;
			}
		}
	});		  
})(jQuery);