$(function () {


    $('.subnavbar').find('li').each(function (i) {

        var mod = i % 3;

        if (mod === 2) {
            $(this).addClass('subnavbar-open-right');
        }

    });

    //获取登陆信息
    $.getJSON("/ad-test/User/getCurrentUserInfo", function (result) {
        if (result.code == "999") {
            $('#userInfo').html("访客模式");
            $('#logout').hide();
            //localStorage.user = null;
            localStorage.setItem('user', null);
        } else {
            $('#userInfo').html(result.data.user.name);
            $('#login').hide();
            //localStorage.user = result.data.user;
            localStorage.setItem('user', JSON.stringify(result.data.user));
        }

    })


});