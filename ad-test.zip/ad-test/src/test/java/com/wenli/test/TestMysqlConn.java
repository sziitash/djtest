package com.wenli.test;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestMysqlConn {
	/**
	 * @description: 测试数据源是否可用
	 * @date: 2016年7月13日 下午5:13:59
	 * @author: wenli
	 */

	public static void main(String[] args) {
		Connection conn;
		Statement stmt;
		ResultSet rs;

		try {
			Class.forName("com.mysql.jdbc.Driver").newInstance();

			conn = DriverManager.getConnection(
					"jdbc:mysql://172.17.49.51:3306/tms", "root", "root");

			stmt = conn.createStatement();

			rs = stmt.executeQuery("select * from tdept");

			while (rs.next()) {
				String num = rs.getString("id");
				String name = rs.getString("name");		
				System.out.println(num + " " + name );
			}
			stmt.close();
			conn.close();
		} catch (Exception e) {
			e.printStackTrace();
			System.out.println("连接失败");
		}
	}

}
